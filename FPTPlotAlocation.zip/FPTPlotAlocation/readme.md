# Instruções de Utilização do plugin QGIS

Para instruções de utilização deste plugin QGIS, [clique aqui](https://richterv.github.io/fptoolsdoc/plot_alocation.html).
